<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class RoleUser extends Model
{
    //
}

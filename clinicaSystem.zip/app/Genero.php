<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class Genero extends Model
{
    protected $fillable = ['id','nombre'];

}

<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class Tipopago extends Model
{
    protected $fillable = ['id','nombre','detalle'];

    
}

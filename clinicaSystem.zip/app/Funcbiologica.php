<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class Funcbiologica extends Model
{
    protected $fillable = ['id','nombre','resultado','detalle'];

    
}

<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class Medicamento extends Model
{
    protected $fillable = ['id','nombre','detalle'];

}

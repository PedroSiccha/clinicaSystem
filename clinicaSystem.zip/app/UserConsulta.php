<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class UserConsulta extends Model
{
    //
}

<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class Area extends Model
{
    protected $fillable = ['id','nombre','descrpcion'];

    
}

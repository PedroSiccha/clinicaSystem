<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class UserTurno extends Model
{
    //
}

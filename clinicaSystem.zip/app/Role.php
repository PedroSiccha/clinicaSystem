<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    //
}

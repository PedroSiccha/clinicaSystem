<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class Instruccion extends Model
{
    protected $fillable = ['id','nombre'];

}

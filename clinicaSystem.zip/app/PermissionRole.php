<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class PermissionRole extends Model
{
    //
}

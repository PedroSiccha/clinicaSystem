<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class TipoExamene extends Model
{
    protected $fillable = ['id','nombre'];

}

<?php

namespace clinicaSystem;

use Illuminate\Database\Eloquent\Model;

class PermissionUser extends Model
{
    //
}

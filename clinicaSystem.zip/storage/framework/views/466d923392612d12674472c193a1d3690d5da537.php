<?php $__env->startSection('title'); ?>
 Pacientes   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_title">
        <h2>Gestion de Pacientes <small>Lista</small></h2>
        <ul class="nav navbar-right panel_toolbox">
          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
          </li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="#">Settings 1</a>
              </li>
              <li><a href="#">Settings 2</a>
              </li>
            </ul>
          </li>
          <li><a class="close-link"><i class="fa fa-close"></i></a>
          </li>
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        
        <table id="datatable" class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>#</th>
              <th>Nombres</th>
              <th>DNI</th>
              <th>Teléfono</th>
              <th>Correo</th>
              <th>Dirección</th>
              <th>Gestión</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $paciente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($pac->id); ?></th>
              <td>    <?php echo e($gen->nombre); ?> </td>
              <td>    <?php echo e($gen->doc); ?> </td>
              <td>    <?php echo e($gen->telefono); ?> </td>
              <td>    <?php echo e($gen->email); ?> </td>
              <td>    <?php echo e($gen->direccion); ?> </td>
              <td>@mdo</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
        </table>

      </div>
    </div>
  </div>

   
       
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
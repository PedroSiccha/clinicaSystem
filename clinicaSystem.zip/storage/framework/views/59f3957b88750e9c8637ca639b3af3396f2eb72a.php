<?php $__env->startSection('title'); ?>
 Pagar Cita   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>